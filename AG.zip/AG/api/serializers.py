from rest_framework import serializers
from products.models import Product, Category
from orders.models import Order, OrderItem
from reviews.models import Review
from wishlist.models import Wishlist

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'slug']

class ProductSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(
        queryset=Category.objects.all(),
        source='category',
        write_only=True
    )
    
    class Meta:
        model = Product
        fields = ['id', 'name', 'slug', 'description', 'price', 'image', 'category', 'category_id', 'available', 'stock', 'sku']
        read_only_fields = ['id']

class ReviewSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField(read_only=True)
    
    class Meta:
        model = Review
        fields = ['id', 'product', 'user', 'rating', 'comment', 'created_at']
        read_only_fields = ['user']

class OrderItemSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    
    class Meta:
        model = OrderItem
        fields = ['id', 'product', 'price', 'quantity']

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = Order
        fields = ['id', 'user', 'first_name', 'last_name', 'email', 'address', 'postal_code', 
                 'city', 'state', 'country', 'phone', 'created', 'updated', 'status', 
                 'total_amount', 'payment_id', 'tracking_number', 'items']
        read_only_fields = ['user']

class CartSerializer(serializers.Serializer):
    items = serializers.ListField(child=serializers.DictField())
    total_price = serializers.DecimalField(max_digits=10, decimal_places=2)

    def to_representation(self, instance):
        return {
            'items': [
                {
                    'product': {
                        'id': item['product'].id,
                        'name': item['product'].name,
                        'price': str(item['price']),
                    },
                    'quantity': item['quantity'],
                    'total_price': str(item['total_price']),
                }
                for item in instance
            ],
            'total_price': str(instance.get_total_price()),
        }

class WishlistSerializer(serializers.ModelSerializer):
    products = ProductSerializer(many=True, read_only=True)
    
    class Meta:
        model = Wishlist
        fields = ['id', 'user', 'products']
        read_only_fields = ['user'] 