from django.shortcuts import render
from rest_framework import viewsets, views, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from products.models import Product, Category
from orders.models import Order
from reviews.models import Review
from cart.cart import Cart
from wishlist.models import Wishlist
from .serializers import (
    ProductSerializer,
    CategorySerializer,
    ReviewSerializer,
    OrderSerializer,
    CartSerializer,
    WishlistSerializer
)

# Create your views here.

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class ReviewViewSet(viewsets.ModelViewSet):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class OrderViewSet(viewsets.ModelViewSet):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class CartView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        cart = Cart(request)
        serializer = CartSerializer(cart)
        return Response(serializer.data)

    def post(self, request):
        cart = Cart(request)
        product_id = request.data.get('product_id')
        quantity = int(request.data.get('quantity', 1))
        product = get_object_or_404(Product, id=product_id)
        cart.add(product=product, quantity=quantity)
        serializer = CartSerializer(cart)
        return Response(serializer.data)

    def delete(self, request):
        cart = Cart(request)
        product_id = request.data.get('product_id')
        product = get_object_or_404(Product, id=product_id)
        cart.remove(product)
        serializer = CartSerializer(cart)
        return Response(serializer.data)

class WishlistView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        wishlist, created = Wishlist.objects.get_or_create(user=request.user)
        serializer = WishlistSerializer(wishlist)
        return Response(serializer.data)

    def post(self, request):
        wishlist, created = Wishlist.objects.get_or_create(user=request.user)
        product_id = request.data.get('product_id')
        product = get_object_or_404(Product, id=product_id)
        wishlist.products.add(product)
        serializer = WishlistSerializer(wishlist)
        return Response(serializer.data)

    def delete(self, request):
        wishlist = get_object_or_404(Wishlist, user=request.user)
        product_id = request.data.get('product_id')
        product = get_object_or_404(Product, id=product_id)
        wishlist.products.remove(product)
        serializer = WishlistSerializer(wishlist)
        return Response(serializer.data)
