from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from products.models import Product
from .models import Wishlist, WishlistItem

# Create your views here.

@login_required
def wishlist_detail(request):
    wishlist, created = Wishlist.objects.get_or_create(user=request.user)
    return render(request, 'wishlist/wishlist_detail.html', {'wishlist': wishlist})

@login_required
def wishlist_add(request, product_id):
    wishlist, created = Wishlist.objects.get_or_create(user=request.user)
    product = get_object_or_404(Product, id=product_id)
    WishlistItem.objects.get_or_create(wishlist=wishlist, product=product)
    messages.success(request, 'Product added to wishlist successfully.')
    return redirect('products:product_detail', slug=product.slug)

@login_required
def wishlist_remove(request, product_id):
    wishlist = get_object_or_404(Wishlist, user=request.user)
    product = get_object_or_404(Product, id=product_id)
    WishlistItem.objects.filter(wishlist=wishlist, product=product).delete()
    messages.success(request, 'Product removed from wishlist successfully.')
    return redirect('wishlist:wishlist_detail')
