from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from .models import Order, OrderItem
from cart.cart import Cart
import stripe

stripe.api_key = settings.STRIPE_SECRET_KEY

@login_required
def order_create(request):
    cart = Cart(request)
    if request.method == 'POST':
        order = Order.objects.create(user=request.user)
        for item in cart:
            OrderItem.objects.create(
                order=order,
                product=item['product'],
                price=item['price'],
                quantity=item['quantity']
            )
        cart.clear()
        return redirect('orders:payment_process', order_id=order.id)
    return render(request, 'orders/order_create.html', {'cart': cart})

@login_required
def order_list(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'orders/order_list.html', {'orders': orders})

@login_required
def order_detail(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'orders/order_detail.html', {'order': order})

@login_required
def payment_process(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if request.method == 'POST':
        success = False
        try:
            # Create Stripe Checkout Session
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'inr',
                        'product_data': {
                            'name': f'Order #{order.id}',
                        },
                        'unit_amount': int(order.get_total_cost() * 100),  # amount in paise
                    },
                    'quantity': 1,
                }],
                mode='payment',
                success_url=request.build_absolute_uri('/orders/payment/done/'),
                cancel_url=request.build_absolute_uri('/orders/payment/canceled/'),
            )
            return redirect(session.url, code=303)
        except Exception as e:
            messages.error(request, 'There was a problem processing your payment.')
            return redirect('orders:order_detail', order_id=order.id)
    return render(request, 'orders/payment_process.html', {'order': order,
                                                         'stripe_public_key': settings.STRIPE_PUBLIC_KEY})

@login_required
def payment_done(request):
    messages.success(request, 'Your payment was successful!')
    return render(request, 'orders/payment_done.html')

@login_required
def payment_canceled(request):
    messages.error(request, 'Your payment was canceled.')
    return render(request, 'orders/payment_canceled.html')
