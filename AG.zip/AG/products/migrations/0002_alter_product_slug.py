from django.db import migrations, models
from django.utils.text import slugify

def make_slugs_unique(apps, schema_editor):
    Product = apps.get_model('products', 'Product')
    seen_slugs = {}
    
    for product in Product.objects.all():
        original_slug = slugify(product.name)
        slug = original_slug
        counter = 1
        
        while slug in seen_slugs:
            slug = f"{original_slug}-{counter}"
            counter += 1
        
        seen_slugs[slug] = True
        product.slug = slug
        product.save()

class Migration(migrations.Migration):

    dependencies = [
        ('products', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(make_slugs_unique),
        migrations.AlterField(
            model_name='product',
            name='slug',
            field=models.SlugField(max_length=200, unique=True),
        ),
    ] 