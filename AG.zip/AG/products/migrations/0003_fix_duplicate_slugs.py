from django.db import migrations
from django.utils.text import slugify

def fix_duplicate_slugs(apps, schema_editor):
    Product = apps.get_model('products', 'Product')
    seen_slugs = {}
    
    for product in Product.objects.all():
        original_slug = product.slug
        slug = original_slug
        counter = 1
        
        while slug in seen_slugs:
            slug = f"{original_slug}-{counter}"
            counter += 1
        
        seen_slugs[slug] = True
        if slug != original_slug:
            product.slug = slug
            product.save()

class Migration(migrations.Migration):

    dependencies = [
        ('products', '0002_alter_product_slug'),
    ]

    operations = [
        migrations.RunPython(fix_duplicate_slugs),
    ] 