from django.shortcuts import render

def button_examples(request):
    return render(request, 'buttons.html') 