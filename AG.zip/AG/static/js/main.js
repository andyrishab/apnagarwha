// Custom JavaScript for APNA GARWHA

// Product Gallery
class ProductGallery {
    constructor() {
        this.mainImage = document.querySelector('.product-main-image');
        this.thumbnails = document.querySelectorAll('.product-thumbnail');
        this.init();
    }

    init() {
        if (this.thumbnails) {
            this.thumbnails.forEach(thumb => {
                thumb.addEventListener('click', () => {
                    this.mainImage.src = thumb.src;
                    this.thumbnails.forEach(t => t.classList.remove('active'));
                    thumb.classList.add('active');
                });
            });
        }
    }
}

// Quantity Handler
class QuantityHandler {
    constructor() {
        this.quantityInputs = document.querySelectorAll('.quantity-input');
        this.init();
    }

    init() {
        this.quantityInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                const value = parseInt(e.target.value);
                if (value < 1) e.target.value = 1;
            });
        });
    }
}

// Search Handler
class SearchHandler {
    constructor() {
        this.searchInput = document.querySelector('.search-input');
        this.searchResults = document.querySelector('.search-results');
        this.init();
    }

    init() {
        if (this.searchInput) {
            this.searchInput.addEventListener('input', this.debounce(() => {
                this.performSearch();
            }, 300));
        }
    }

    async performSearch() {
        const query = this.searchInput.value;
        if (query.length < 2) {
            this.searchResults.innerHTML = '';
            return;
        }

        try {
            const response = await fetch(`/api/products/search/?q=${query}`);
            const data = await response.json();
            this.displayResults(data);
        } catch (error) {
            console.error('Search error:', error);
        }
    }

    displayResults(results) {
        if (!this.searchResults) return;
        
        this.searchResults.innerHTML = results.map(product => `
            <a href="${product.url}" class="search-result-item">
                <img src="${product.image}" alt="${product.name}">
                <div class="search-result-info">
                    <h6>${product.name}</h6>
                    <p>₹${product.price}</p>
                </div>
            </a>
        `).join('');
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Initialize all functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ProductGallery();
    new QuantityHandler();
    new SearchHandler();
}); 