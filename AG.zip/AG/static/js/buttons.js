/**
 * Button Utility Functions
 */

// Function to add loading state to a button
function setButtonLoading(button, isLoading) {
    if (isLoading) {
        button.classList.add('btn-loading');
        button.disabled = true;
    } else {
        button.classList.remove('btn-loading');
        button.disabled = false;
    }
}

// Function to create a button with icon
function createButtonWithIcon(text, iconClass, buttonClass = 'btn-primary-custom', size = '') {
    const button = document.createElement('button');
    button.className = `btn-custom ${buttonClass} ${size} btn-icon`;
    button.innerHTML = `<i class="${iconClass}"></i> ${text}`;
    return button;
}

// Function to create a button with confirmation
function createConfirmButton(text, confirmMessage, onClick, buttonClass = 'btn-danger-custom') {
    const button = document.createElement('button');
    button.className = `btn-custom ${buttonClass}`;
    button.textContent = text;
    button.addEventListener('click', (e) => {
        if (confirm(confirmMessage)) {
            onClick(e);
        }
    });
    return button;
}

// Function to create a toggle button
function createToggleButton(text, activeText, isActive = false, onClick) {
    const button = document.createElement('button');
    button.className = `btn-custom ${isActive ? 'btn-success-custom' : 'btn-secondary-custom'}`;
    button.textContent = isActive ? activeText : text;
    button.addEventListener('click', () => {
        isActive = !isActive;
        button.className = `btn-custom ${isActive ? 'btn-success-custom' : 'btn-secondary-custom'}`;
        button.textContent = isActive ? activeText : text;
        if (onClick) onClick(isActive);
    });
    return button;
}

// Function to create a button group
function createButtonGroup(buttons) {
    const group = document.createElement('div');
    group.className = 'btn-group';
    buttons.forEach(button => {
        group.appendChild(button);
    });
    return group;
}

// Example usage:
document.addEventListener('DOMContentLoaded', function() {
    // Example: Add loading state to all submit buttons
    const submitButtons = document.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(button => {
        button.addEventListener('click', function() {
            setButtonLoading(this, true);
            // The form submission will happen automatically
        });
    });
    
    // Example: Create a button with icon
    const addToCartButton = createButtonWithIcon('Add to Cart', 'bi bi-cart-plus', 'btn-primary-custom');
    document.querySelector('.product-actions')?.appendChild(addToCartButton);
    
    // Example: Create a confirmation button
    const deleteButton = createConfirmButton('Delete', 'Are you sure you want to delete this item?', function() {
        console.log('Item deleted');
    });
    document.querySelector('.delete-actions')?.appendChild(deleteButton);
    
    // Example: Create a toggle button
    const likeButton = createToggleButton('Like', 'Liked', false, function(isActive) {
        console.log(isActive ? 'Item liked' : 'Item unliked');
    });
    document.querySelector('.like-actions')?.appendChild(likeButton);
}); 