from django.urls import path
from . import views

app_name = 'reviews'

urlpatterns = [
    path('product/<int:product_id>/', views.review_list, name='review_list'),
    path('add/<int:product_id>/', views.review_add, name='review_add'),
    path('edit/<int:review_id>/', views.review_edit, name='review_edit'),
    path('delete/<int:review_id>/', views.review_delete, name='review_delete'),
] 