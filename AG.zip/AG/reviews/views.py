from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from products.models import Product
from .models import Review
from .forms import ReviewForm

def review_list(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    reviews = Review.objects.filter(product=product, is_approved=True)
    return render(request, 'reviews/review_list.html', {
        'product': product,
        'reviews': reviews
    })

@login_required
def review_add(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.user = request.user
            review.product = product
            review.save()
            messages.success(request, 'Your review has been submitted and is awaiting approval.')
            return redirect('products:product_detail', slug=product.slug)
    else:
        form = ReviewForm()
    return render(request, 'reviews/review_form.html', {
        'form': form,
        'product': product
    })

@login_required
def review_edit(request, review_id):
    review = get_object_or_404(Review, id=review_id, user=request.user)
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your review has been updated.')
            return redirect('products:product_detail', slug=review.product.slug)
    else:
        form = ReviewForm(instance=review)
    return render(request, 'reviews/review_form.html', {
        'form': form,
        'review': review,
        'product': review.product
    })

@login_required
def review_delete(request, review_id):
    review = get_object_or_404(Review, id=review_id, user=request.user)
    product_slug = review.product.slug
    review.delete()
    messages.success(request, 'Your review has been deleted.')
    return redirect('products:product_detail', slug=product_slug)
